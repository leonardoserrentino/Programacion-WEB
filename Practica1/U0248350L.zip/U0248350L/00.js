//Definimos una variable y le asignamos un valor.

alert("Accediendo al ejercicio 00");
var first_variable;

first_variable=1;

console.log(first_variable); //mostramos el valor por consola.
//Asignamos nuevo valor y lo volvemos a mostrar por consola.
first_variable="Nuevo valor asignado a la variable";
console.log(first_variable);

//Asignamos nuevo valor a la variable cambiandola de tipo
first_variable="99.99% es casi 100%"
console.log(first_variable)


